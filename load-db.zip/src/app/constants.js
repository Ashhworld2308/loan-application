export const API_URL = "http://localhost:5001";

export const ApplicationStatusList = [
    { Requested: "REQUESTED" },
    { PENDING: "PENDING" },
    { APPROVED: "APPROVED" },
    { REJECTED: "REJECTED" }
]